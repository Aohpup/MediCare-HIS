#pragma once
#ifndef LIMITS_H
#define LIMITS_H
//宏定义:全局常量设置
#define STR_LEN 50         // str 通用字符串长度
#define ID_LEN 25          // ID 编号长度
#define BED_ID_LEN 64      // bedId 床位编号长度
#define DEPT_NUM 5         // department 科室最少数量
#define WARD_TYPE_NUM 3    // ward 病房种类最少数量
#define MAX_WARD_BEDS 10     // ward 每个病房的最大床位数量
#define MAX_APP 5         // appointment 预约挂号每个时段的最大挂号数量
#define SLOT_COUNT 17     // appointment 时间段数量（含4个午休时段）
#define DATE_STR_LEN 20     // date 日期字符串长度 XXXX-XX-XX or XXXX/XX/XX
#define TIME_STR_LEN 10     // time 时间字符串长度 XX:XX:XX

//数据文件路径
#define DRUG_FILE "HIS_drugs.txt"				//药品数据文件
#define DOCTOR_FILE "HIS_doctors.txt"			//医生数据文件
#define DEPARTMENT_FILE "HIS_departments.txt"	//科室数据文件
#define WARD_FILE "HIS_wards.txt"				//病房数据文件
#define PATIENT_FILE "HIS_patients.txt"			//患者数据文件
#define QUEUE_TICKET_FILE "HIS_queue_tickets.txt" //排队挂号数据文件
#define EXAM_ITEM_FILE "HIS_exam_items.txt"      //检查项目字典文件
#define EXAM_ORDER_FILE "HIS_exam_orders.txt"    //检查申请/结果文件

//备份与状态文件
#define BACKUP_DIR "data_backup"                 //数据备份目录
#define STATUS_FILE "HIS_status.txt"             //退出状态文件
#define FINANCE_FILE "HIS_finance.txt"           //财务数据文件
#define ADMIN_FILE "HIS_admin.txt"               //管理员凭据文件

#endif // !LIMITS_H
 