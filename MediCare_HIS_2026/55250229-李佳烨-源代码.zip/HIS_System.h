#pragma once
#ifndef HIS_SYSTEM_H
#define HIS_SYSTEM_H
#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>
#include"PauseUtil.h"
#include"DayTimeUtils.h"
#include"ConfirmFunc.h"
#include"ProjectLimits.h"
#include"StringCheck.h"

//.h/.c 文件共有12567行，包含了医疗管理系统的核心数据结构定义、全局变量声明，以及系统初始化、数据加载与保存等功能函数的声明。


//测试信息
extern bool TEST_SYSTEM_DEBUG;		//是否启用测试（true启用，false禁用）

extern bool AUTO_BACKUP_DATA;		//自动备份数据到backup目录（true启用，false禁用）

extern bool TEST_NIGHT_TIME;		//测试夜间急诊时段（true启用，false禁用）

extern long long fixedAsset;	//医院固定资产（初始值为1000万，单位：元）

//S链表存储数据
//S.1药品
typedef struct Drug {
	char drugId[ID_LEN];			//商品编号
	char drugGbCode[16];		//国标码(国家药品本位码 共14位)
	char genericName[STR_LEN];		//通用名
	char tradeName[STR_LEN];		//商品名
	char alias[STR_LEN];			//别称/俗名
	int stock;						//剩余库存
	double price;					//价格(元)
	struct Drug* next;
}Drug;

//S.2医生&科室
	//S.2.1医生
	
//医生排班信息结构体
typedef struct DoctorSchedule {
	char day[DATE_STR_LEN];				//排班日期 (格式: XXXX-XX-XX)
	int quota[SLOT_COUNT + 1];			//排班时间段预约限额，0表示该时段未排班，正整数表示该时段的最大挂号数，默认为0、最大值为MAX_APP（每时段最多5人）
	int bookedCount[SLOT_COUNT + 1];	//已预约挂号数量
	struct DoctorSchedule* next;
} DoctorSchedule;

//医生信息结构体
typedef struct doctor {
	char doctorId[ID_LEN];			//医生编号
	char doctorName[STR_LEN];		//医生姓名
	char department[STR_LEN];		//所属一级科室名称
	char subDepartment[STR_LEN];		//所属二级科室名称
	char subDeptId[ID_LEN];			//所属诊室（办公室）编号
	char password[STR_LEN];			//登录密码

	DoctorSchedule* scheduleHead;	//医生排班链表头

	struct doctor* next;
}doctor;
	//S.2.2科室
typedef struct SubDepartment {
	char subDeptName[STR_LEN];     // 二级科室名称 (具体科室名字，如：心内科)
	char subDeptId[ID_LEN];        // 具体诊室的编号
	struct SubDepartment* next;
}SubDepartment;

typedef struct Department {
	char categoryName[STR_LEN];    // 一级科室名称 (科室类名字，如：内科)
	char categoryId[ID_LEN];       // 一级科室代码
	SubDepartment* subDeptHead;    // 该大类下的具体科室链表
	struct Department* next;
}Department;

//S.3病床&病房
	//S.3.1病床
	typedef struct Bed {
		char bedId[BED_ID_LEN];			//病床编号 (病房内唯一编号，格式可自定义，如：Z15101，其中Z151表示病房编号，01表示床位编号)
		bool isOccupied;			//是否被使用
		char patient[ID_LEN];		//患者编号
		struct Bed* next;
	}Bed;

	//S.3.2病房种类
	typedef enum {
		WARD_NORMAL = 1,			// 普通病房 (设为1便于在终端上调用)
		WARD_VIP,					// VIP病房
		WARD_ICU					// ICU病房
	} WardType;

	//S.3.3病房
	typedef struct Ward {
		char wardId[ID_LEN];		//病房编号
		WardType type;				//病房种类
		char department[STR_LEN];	//病房所属科室
		double price;				//病房每日价格（预留）
		Bed* bedListHead;			//病房内床位数
		struct Ward* next;
	} Ward;

//S.4医疗记录
	//挂号、看诊、检查、住院
typedef enum {
	REC_REG = 1,    // 挂号 Registration
	REC_VIEW,       // 看诊 Consultation
	REC_STAY,       // 住院 Hospitalization
	REC_MED         // 处方 Medication
} RecordType;

typedef enum {
	PATIENT_GENERAL = 1,	// 普通患者
	PATIENT_VIP,			// VIP患者
	PATIENT_EMERGENCY		// 急诊患者
} PatientType;

//初步患者编号生成规则,TODO: 之后根据实际需求调整生成规则，增加日期前缀、患者类别等
#define STARTING_PATIENT_ID 10000000	//患者编号起始值
extern int currentPatientId;			//当前患者编号计数器（全局变量，初始值为STARTING_PATIENT_ID）

typedef struct RegistrationRecord {
	char recordId[ID_LEN];			// 挂号记录编号
	char department[STR_LEN];		// 挂号科室
	char doctorId[ID_LEN];			// 挂号医生编号
	char date[ID_LEN];				// 挂号日期
	char time[ID_LEN];				// 挂号时间
	//RegistrationRecord* currRegTail;//当前患者挂号记录链表的末尾指针（仅在加载数据时使用，其他时候保持为NULL）
	struct RegistrationRecord* next;
} RegistrationRecord;

typedef struct ConsultationRecord {
	char recordId[ID_LEN];			// 医疗记录编号
	RecordType record;				// 记录类型（仅看诊）
	char details[512];				//报告细节内容
	char date[ID_LEN];				//日期
	char doctorId[ID_LEN];			//所属医生编号
	struct ConsultationRecord* next;
} ConsultationRecord;

// 检查项目字典
typedef struct ExamItem {
	char itemId[ID_LEN];		// 项目编号
	char itemName[STR_LEN];		// 项目名称
	double price;				// 单价（预留）
	char department[STR_LEN];	// 执行科室
	struct ExamItem* next;
} ExamItem;

// 检查申请单条目（子项目）
typedef struct ExamOrderItem {
	char itemId[ID_LEN];		// 项目编号
	char itemName[STR_LEN];		// 项目名称
	double price;				// 单价（预留）
	char result[512];			// 检查结果
	bool finished;				// 是否完成
	struct ExamOrderItem* next;
} ExamOrderItem;

// 检查申请记录 （主项目）
typedef struct ExamOrder {
	char orderId[ID_LEN];		// 申请单编号
	char patientId[ID_LEN];		// 患者编号
	char doctorId[ID_LEN];		// 开单医生编号
	char date[DATE_STR_LEN];	// 开单日期
	char status[STR_LEN];		// 状态（Pending/Finished）
	ExamOrderItem* itemHead;	// 申请项目列表
	struct ExamOrder* next;
} ExamOrder;

typedef struct StayRecord {
	char recordId[ID_LEN];			// 住院记录编号
	char startDate[ID_LEN];			// 住院开始日期
	char duration[ID_LEN];			// 住院时长
	char endDate[ID_LEN];			// 住院结束日期，如果仍在住院则为"未出院"或类似标识
	char deptInfo[STR_LEN];			// 科室描述（如 "科室[内科]"）
	char doctorId[ID_LEN];			// 所属医生编号
	char wardId[ID_LEN];			// 关联病房编号
	char bedId[BED_ID_LEN];			// 床位编号（如 "P10401"）
	int dischargeApproved;			// 出院许可(0=不可出院,1=准许出院)
	char isChargeDate[DATE_STR_LEN];	// 患者最终缴费办结日期（住院费用结清后记录）
	struct StayRecord* next;
} StayRecord;

//S.5患者节点
typedef struct Patient {
	char patientId[ID_LEN];			//患者编号
	char name[STR_LEN];				//患者姓名
	char phone[ID_LEN];				//患者电话
	char idCard[18 + 3];			//患者身份证号
	char gender[STR_LEN];			//患者性别
	int age;					//患者年龄
	PatientType type;				//患者类别 (普通/VIP/急诊)
	double realBalance;			//实际充值余额
	double bonusBalance;			//赠送余额
	int loginCount;				//登录次数

	RegistrationRecord* regHead;		// 挂号记录链表头
	ConsultationRecord* viewHead;		// 看诊记录链表头
	StayRecord* stayHead;				// 住院记录链表头
	ConsultationRecord* medHead;		// 处方记录链表头（复用ConsultationRecord）

	RegistrationRecord* currRegTail;			// 当前患者挂号记录链表的末尾指针
	ConsultationRecord* currViewTail;		// 当前患者看诊记录链表的末尾指针
	StayRecord* currStayTail;				// 当前患者住院记录链表的末尾指针
	ConsultationRecord* currMedTail;		// 当前患者处方记录链表的末尾指针

	struct Patient* next;
} Patient;


extern const char* slot_names[SLOT_COUNT + 1];		// 挂号预约时间段列表（含晚间急诊）

typedef enum {
	SLOT_INVALID = 0,	// 无效时间段
	SLOT_0800_0830, SLOT_0830_0900, SLOT_0900_0930, SLOT_0930_1000 = 4,
	SLOT_1000_1030, SLOT_1030_1100, SLOT_1100_1130 = 7,
	SLOT_1130_1200, SLOT_1200_1230, SLOT_1230_1300, SLOT_1300_1330 = 11,	// 8 - 11 午休时段，可根据实际需求调整开放与否
	SLOT_1330_1400, SLOT_1400_1430, SLOT_1430_1500 = 14,
	SLOT_1500_1530, SLOT_1530_1600, SLOT_1600_1630 = 17,
	SLOT_NIGHT = 18		// 晚间急诊（独立于白天门诊）
} TimeSlot;


//患者排队状态枚举
typedef enum {
	STATUS_WAITING,    // 等待叫号
	STATUS_CALLED,     // 已叫号（但未进入诊室）
	STATUS_IN_ROOM,    // 就诊中
	STATUS_FINISHED,   // 就诊结束
	STATUS_MISSED,     // 过号未应
	STATUS_CANCELLED   // 爽约/取消
} PatientStatus;

typedef struct HIS_System {
	Drug* drugHead;
	Drug* drugDisplayHead;
	doctor* docHead;
	SubDepartment* subDeptHead;
	Department* deptHead;
	Ward* wardHead;
	ExamItem* examItemHead;
	ExamOrder* examOrderHead;
	Patient* patientHead;
	Patient* patientTail;
	double hospitalRevenue;		// 全院总收入
	double hospitalExpenditure;	// 全院总支出
} HIS_System;


// 初始化医疗管理系统底座
void initSystem(HIS_System* sys);
//Warning: 添加数据前请务必先调用 initSystem() 初始化系统底座，否则可能会导致严重错误！！！

//从文件加载系统数据
void loadFileAllData(HIS_System* sys);

//保存系统数据到文件
void saveSystemData(HIS_System* sys);

//释放系统内存（当前至少释放药品原始链表和显示链表）
//TODO：新的原始和显示链表
void cleanupSystemMemory(HIS_System* sys);

//累加医院收入/支出
void addHospitalRevenue(HIS_System* sys, double amount);
void addHospitalExpenditure(HIS_System* sys, double amount);

//保存财务数据到文件
void saveFinanceData(HIS_System* sys);

//对所有在住患者执行每日住院计费
void chargeAllInpatientsDaily(HIS_System* sys);

//管理员：财务与库存报表统计
void showFinanceStatistics(HIS_System* sys);


#endif // HIS_SYSTEM_H